/**
 * Accounts list file
 * write your accounts like this
 * export const accountLists = [
 *     "MANGOPRIVKEY1",
 *     "MANGOPRIVKEY2",
 *     "MANGOPRIVKEY3",
 * ];
 *
 */

export const accountList = [];
