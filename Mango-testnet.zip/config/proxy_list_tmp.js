/**
 * 
 * Example : 
 * export const proxyList = [
    "http://proxyUser:proxyPass@proxyHost:proxyPort",
    "http://proxyUser:proxyPass@proxyHost:proxyPort",
    "http://proxyUser:proxyPass@proxyHost:proxyPort",
  ];
 */

export const proxyList = [];
