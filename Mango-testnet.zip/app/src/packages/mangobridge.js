export const MANGOBRIDGEPACKAGE = {
    'ADDRESS': "0x7ee0e9fbb882c138e3bd7194b479efd7a1b64314e8d6afa75686c1207ec68261",
    'MODULE': {
      'BRIDGE': {
        'BRIDGEXECUTOR': "0x48ec5f9f849b80803b6052c2254953d8f85e9c2191e645954f6b96317d12ece7",
        'CLOCK': "0x6"
      }
    }
  };