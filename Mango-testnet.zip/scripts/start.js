import _0x540680 from 'fs';
import _0x1bb255 from 'path';

async function salinFolder(sumber, tujuan) {
  try {
    await _0x540680.promises.mkdir(tujuan, { recursive: true });
    const daftarItem = await _0x540680.promises.readdir(sumber, { withFileTypes: true });
    for (let item of daftarItem) {
      const pathSumber = _0x1bb255.join(sumber, item.name);
      const pathTujuan = _0x1bb255.join(tujuan, item.name);
      if (item.isDirectory()) {
        await salinFolder(pathSumber, pathTujuan);
      } else {
        await _0x540680.promises.copyFile(pathSumber, pathTujuan);
      }
    }
    console.log("Berhasil menyalin dari " + sumber + " ke " + tujuan + " (BUATAN NANDAA GANTENG)");
  } catch (error) {
    console.error("Gagal menyalin dari " + sumber + " ke " + tujuan + ':', error);
  }
}

const akunSumber = _0x1bb255.join(process.cwd(), "accounts");
const configSumber = _0x1bb255.join(process.cwd(), "config");
const akunTujuan = _0x1bb255.join(process.cwd(), "app", "accounts");
const configTujuan = _0x1bb255.join(process.cwd(), "app", "config");

(async () => {
  await salinFolder(akunSumber, akunTujuan);
  await salinFolder(configSumber, configTujuan);
  console.log("Memulai aplikasi... (BUATAN NANDAA GANTENG)");
  await import(_0x1bb255.join(process.cwd(), "app", "index.js"));
})();